package net.khoudmi.ebankingbackend.enums;

public enum OperationType {
    DEBIT, CREDIT
}
