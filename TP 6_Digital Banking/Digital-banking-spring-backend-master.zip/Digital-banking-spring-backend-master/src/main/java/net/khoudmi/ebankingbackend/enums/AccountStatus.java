package net.khoudmi.ebankingbackend.enums;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED
}
